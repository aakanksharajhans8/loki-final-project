package com.insurance.underwriting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnderwritingApplicationTests {

	@Test
	void contextLoads() {
	}

}
